# jsh-app

## Project setup
```
yarn
```

### Compiles and hot-reloads for development
```
yarn devh5
```

### Compiles and minifies for production
```
yarn build
```

### Customize configuration
See [Configuration Reference](https://cli.vuejs.org/config/).
