
const data = [
  'pages/index/index',
  'pages/login/login/login',
  'pages/goods/goodsList',
  'pages/shoppingCart/shoppingCart',
  'pages/shoppingCart/orderConfirm',
  'pages/shoppingCart/orderConfirmRemarks',
  'pages/productDetail/productDetail',
  'pages/category/category',
  'pages/market/marketList',
  'pages/market/marketDetail',
  'pages/orderList/orderList',
  'pages/messageInfoList/messageInfoList',
  'pages/mine/myBaseInfo',
  'pages/mine/mySignInfo'
];
export default { data };
