export default {
  h5: {
    development: {
      baseUrl: ''
    },
    production: {
      baseUrl: ''
    }
  },
  'mp-alipay': {
    development: {
      baseUrl: 'https://new.jsh.com'
    },
    production: {
      baseUrl: 'https://new.jsh.com'
    }
  }
};
