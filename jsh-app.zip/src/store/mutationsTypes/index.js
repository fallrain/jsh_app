import USER from './userTypes';

export {
  // eslint-disable-next-line import/prefer-default-export
  USER
};
