const prefix = 'user';
export default {
  UPDATE_USER: `${prefix}.updateUser`,
  GET_USER: `${prefix}.getUser`
};
